+++
title = "Our New Leadership"
date = "2017-01-11"
image = "archimg/2017/handover-2017-1.jpg"
+++
The club welcomes Gail Mackay as our new President, and Pamela Dickson as Vice President.

{{< image src="/archimg/2017/handover-2017-2.jpg" >}}
At the Presidential handover we thanked outgoing President Michael Jamieson for his leadership over an extended term of 18 months.