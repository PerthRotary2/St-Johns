+++
title = "Mock Interviews 2017"
date = "2017-05-09"
+++
Alongside our fellow Rotarians in Perth’s other two clubs we took part in a programme of Mock Interviews across the three main secondary schools in Perth. The project is aimed at pupils who plan to leave school either to take their first step into work or further studies at Perth College. The idea is to give young people experience and advice on how to conduct their first real life job interviews.

We led the project at St John’s Academy. Eight Rotarians took part, five from our club. We worked with 19 pupils on the morning of 9 May, spending approximately 30 mins with each pupil, an immensely rewarding experience.

<i>“It can always be hard to judge the impact, but let me assure you that they were talking about it afterwards and most of them were pleasantly surprised by the experience. I hope we can repeat it again.”</i> - the Guidance Teacher co-ordinating the programme at the Academy.

This is the second year of the project and we, too, are keen to repeat the experience in 2018.