+++
title = "CATH Donation"
date = "2017-03-01"
image = "archimg/2017/cath-2017-800.jpg"
attrib = "Photo: Fraser Band Photography (www.fraserband.co.uk)"
+++
We were delighted to hand over a cheque for £1000 to Brian Cowie from local charity CATH.

Churches Action for the Homeless supports, encourages and promotes the development and delivery of projects to relieve homelessness and poor housing, improve the conditions of life and generally aid the development of persons who are homeless in the Perth & Kinross area.

The funds raised were the result of a Ladies Afternoon Tea, held by the club just before Christmas in the Salutation Hotel. With a theme of Winter Wonderland, 148 ladies came along to an afternoon of entertainment and of course tea and cakes! The ladies enjoyed demonstrations on how to make canapés, floral decorations and cocktails. There was also a fashion show hosted by Phase Eight.

President Gail Mackay said, “We have to thank all the event sponsors and guests who made it such a fun afternoon. The noise levels were amazing and so I guess all the ladies had a great time!. We were delighted with the amount of money raised for this important local charity.” The Ladies Afternoon tea was such a success that we have promised to run another one in the future.