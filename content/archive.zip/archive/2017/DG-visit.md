+++
title = "District Governor's Visit"
date = "2017-08-22"
image = "archimg/2017/DG-2017.jpg"
+++
President Gail Mackay meets District Governor Graeme Archibald.

The Rotary Club of Perth Kinnoull hosted a visit to the three Perth clubs by our District Governor. It was a good opportunity for all the Rotarians in Perth to meet.