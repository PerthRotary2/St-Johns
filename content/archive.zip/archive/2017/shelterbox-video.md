+++
title = "How (Not) to Erect a ShelterBox Tent"
date = "2017-02-07"
+++
This is a light-hearted video showing some of our Rotarians erecting a {{< extlink href="https://www.shelterbox.org" label="ShelterBox" >}} tent during our recent Primary School Quiz night.

{{< video src="/archimg/2017/shelterbox-480p.mp4" >}}

However, there is a much more serious side to these shelters. A ShelterBox consists of a family size tent, thermal blankets, a water purification system, solar lights, tools and cooking utensils. These shelters are designed to be sent anywhere in the world where emergency accommodation is required. Our Rotary Club, together with local primary schools, has been involved in raising funds to purchase these boxes.
