+++
title = "Gavel Competition"
date = "2017-10-02"
image = "archimg/2017/gavel-2017.jpg"
+++
We hosted the Rotary Club of Claverhouse in a light-hearted competition. Our prowess in dominoes, putting, Connect-4 and Jenga was put to the test, and the result an honourable draw.