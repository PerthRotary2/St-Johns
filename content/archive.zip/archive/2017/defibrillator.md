+++
title = "Life Saving Equipment at the Royal George Hotel"
date = "2017-09-27"
image = "archimg/2017/defibrillator.jpg"
+++

We equipped the Royal George Hotel with an Automated External Defibrillator (AED).

This device can make the difference between life and death for someone having a cardiac arrest. Time is critical in this condition, and many public buildings are being equipped with AEDs. Ideally they are used by people with instruction in the device, but they can be used successfully without training. This one will be kept at reception, where it will be available for vistors to the hotel and people nearby. Rotarian Ian Dargie, a first aid instructor, will be training Royal George staff and Rotarians to use it.

In the picture, Ian Dargie and President Gail Mackay present the defibrillator to hotelier Eddie Anderson.