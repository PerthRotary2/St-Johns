+++
title = "Club Assembly"
date = "2017-06-28"
image = "archimg/2017/assembly-2017.jpg"
+++
Once a year, in June, we have a special meeting to plan the club's activities for the next twelve months.

By the River Tay afterwards are Assistant District Governor Alistair Spowage and President Gail Mackay, flanked by members Maureen Young and Rob Burke.