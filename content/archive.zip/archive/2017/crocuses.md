+++
title = "Planting 5000 Crocuses"
date = "2017-10-01"
image = "archimg/2017/crocuses.jpg"
+++

In October we planted 5000 purple crocus corms. The Rotary {{< extlink href="https://www.rotarygbi.org/what-we-do/purple4polio/"  label="Purple4Polio" >}} campaign has been planting crocuses across the country to raise awareness of our effort to eradicate polio.

The colour purple represents the purple dye used to mark the finger of each child in mass immunisation programs across the world.

Our crocuses went to Millenium Park in Kinnoull at a community event, the Walled Garden, several care homes, and a children's nursery. We were helped by residents and staff at the care homes, as well as community volunteers, and everyone seemed to enjoy the experience.