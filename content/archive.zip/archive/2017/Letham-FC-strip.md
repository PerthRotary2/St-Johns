+++
title = "New Strip for Letham FC Sky Blues"
date = "2017-06-20"
image = "archimg/2017/letham-fc.jpg"
+++
The players of Letham FC Sky Blues, with their coaches; and President Gail Mackay and club members.

We were delighted to sponsor new strips for the teams of young players born in 2008 and 2007.