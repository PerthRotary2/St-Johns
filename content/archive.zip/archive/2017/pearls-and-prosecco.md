+++
title = "Ladies of Perth Raised £2700 for Rotary Charity Work"
date = "2017-10-01"
image = "archimg/2017/pearls-and-prosecco-2017.jpg"
+++

Joined by over 115 ladies from Perth, the 'Pearls and Prosecco' afternoon tea at Huntingtower Hotel included a fashion catwalk show by Phase Eight which featured over 40 pieces from their autumn and winter collections.

During an afternoon of fun and fashion, we also heard from contemporary jewellers Number Five about the history of pearls, and from Lynn Urquhart from Debenhams about the magic of perfumes. After some gentle dance moves with Live Active Leisure, the afternoon finished with a headline demonstration by John Gillespie and his team on how to achieve and maintain healthy and beautiful hair.

We were very grateful to all of the businesses and individuals who supported our ladies event and helped us raise this great amount for charity.