+++
title = "Perth Clubs Bowling"
date = "2017-08-28"
image = "archimg/2017/bowling-2017-1.jpg"
+++
Enjoying an evening of bowling with the two other Rotary clubs in Perth.