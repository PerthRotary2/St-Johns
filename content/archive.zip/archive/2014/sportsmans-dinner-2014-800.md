+++
title = "Sportsmans Dinner"
date = "2014-02-21"
image = "archimg/sportsmans-dinner-2014-800.jpg"
+++
We held our annual Sportsman's Dinner at the Salutation Hotel, and would like to thank everyone who contributed to a successful and enjoyable evening.

In the picture: Club President Alexander Stewart (seated centre) is flanked by (left) speaker Stewart Smith and Mike Hope, President, Rotary Club of Perth; and (right) speaker Dougie Donnelly and Peter MacDougall, President, Perth Kinnoull Rotary Club. Behind them, from the left - auctioneer Ian Smith, organiser Heather Stewart, MC Gordon Bannerman; St.Johns vice-President Helen MacKinnon; sponsor Derek Petterson from McLeod Glaziers; and Pipe Major Alistair Duthie.