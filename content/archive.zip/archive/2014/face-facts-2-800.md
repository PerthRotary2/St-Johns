+++
title = "Face Facts donation"
date = "2014-05-28"
image = "archimg/face-facts-2-800.jpg"
+++
We donated £2000 to medical charity “Face Facts”. Sean Laverick, a Trauma Surgeon who lives and works in Tayside, runs the charity and supports the project by providing his specialist skills in places like Pakistan and Afghanistan, treating patients who have suffered facial injuries. In the picture, Sean accepts the cheque from Club President Alexander Stewart and vice-president Helen MacKinnon.