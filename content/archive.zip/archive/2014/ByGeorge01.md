+++
title = "By George, January"
date = "2014-01-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1401v2.pdf"
+++
