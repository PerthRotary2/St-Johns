+++
title = "By George, May"
date = "2014-05-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1405.pdf"
+++
