+++
title = "Donations to Perthshire Women's Aid and 10th Perthshire Scout Group"
date = "2014-05-13"
image = "archimg/donations-2014-800.jpg"
+++
President Alexander Stewart handed over £750 to Joan McLean, Perthshire Women's Aid and VP Helen MacKinnon presented £500 to Dr Colin Fleming of 10th Perthshire Scout Group to go towards their new building project.