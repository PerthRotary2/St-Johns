+++
title = "By George, February"
date = "2014-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1402.pdf"
+++
