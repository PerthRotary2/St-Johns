+++
title = "Our New President"
date = "2014-06-25"
image = "archimg/president-helen-800.jpg"
+++
Trying the 'gong' for size is Helen MacKinnon, our new President. At the Club's Handover Dinner Helen received the chain from outgoing President Alexander Stewart (right) with (left) vice-president Michael Jamieson and (centre) Asst District Governer John Anderson.