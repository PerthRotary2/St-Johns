+++
title = "2014"
date = "2014-12-31"
image = "/archimg/dg-visit-2014-800.jpg"
always_show_text = true
description = "Pictures and By George from 2014."
aliases = [
    "/2014/"
]
+++
The final edition of By George was in May 2014. It was replaced by a short e-Newsletter.