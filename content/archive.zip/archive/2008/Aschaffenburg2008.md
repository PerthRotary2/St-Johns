+++
title = "Visit to Aschaffenburg"
date = "2008-04-15"
image = "archimg/Aschaffenburg2008.jpg"
+++
{{< image src="/archimg/Frankfurt2008.jpg" >}}
High up in Frankfurt

{{< image src="/archimg/Rudesheim2008-02.jpg" >}}
After a boat trip on the Rhine ...

{{< image src="/archimg/Rudesheim2008-01.jpg" >}}
... a picnic at Rudesheim
