+++
title = "By George, April"
date = "2008-04-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0804.pdf"
+++
