+++
title = "By George, March"
date = "2008-03-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0803w.pdf"
+++
