+++
title = "By George, February"
date = "2008-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0802.pdf"
+++
