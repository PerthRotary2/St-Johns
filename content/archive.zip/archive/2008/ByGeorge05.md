+++
title = "By George, May"
date = "2008-05-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0805w.pdf"
+++
