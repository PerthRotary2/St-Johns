+++
title = "By George, December"
date = "2008-12-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0812.pdf"
+++
