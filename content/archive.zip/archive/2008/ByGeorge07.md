+++
title = "By George, July"
date = "2008-07-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0807.pdf"
+++
