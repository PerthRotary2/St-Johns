+++
title = "By George, October"
date = "2008-10-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0810.pdf"
+++
