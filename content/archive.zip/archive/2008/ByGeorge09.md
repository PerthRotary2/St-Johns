+++
title = "By George, September"
date = "2008-09-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0809.pdf"
+++
