+++
title = "By George, June"
date = "2008-06-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0806.pdf"
+++
