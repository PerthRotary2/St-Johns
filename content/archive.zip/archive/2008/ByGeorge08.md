+++
title = "By George, August"
date = "2008-08-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0808.pdf"
+++
