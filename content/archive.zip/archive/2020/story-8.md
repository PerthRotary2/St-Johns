+++
title = "To Boldly Go Where No Woman Had Gone Before"
date = "2020-09-07"
image = "archimg/2020/Mo-VPs.jpg"
+++
[Maureen (Mo) Young recalls her groundbreaking admittance to Rotary]({{< relref "blog-8" >}}).
