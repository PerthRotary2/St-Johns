+++
title = "Our Club in 3 Minutes"
date = "2020-07-21"
image = "archimg/2020/activities-2020-sm.png"
+++
[See some of the fun community activities we get involved in]({{< relref "blog-5" >}}). From fundraising lunches to planting crocuses to installing a community defibrillator ... there's little we haven't tackled!
