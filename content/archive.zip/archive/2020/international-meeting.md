+++
title = "International Meeting"
date = "2020-06-03"
image = "archimg/2020/virtual-meeting-2.png"
+++
There is one advantage to virtual meetings - we can include people from many places.

At this meeting, our speaker was in Leatherhead,
one of our members is in Thailand, and we had a guest from our our twinned Rotary Club of Aschaffenburg-Schönbusch in Germany.

We heard about the excellent work done by {{< extlink href="https://www.globalsightsolutions.org" label="Global Sight Solutions" >}},
a charity that establishes eye hospitals in the developing world to treat avoidable blindness. It was started by a Rotary club and
is supported by Rotary funding and volunteers.