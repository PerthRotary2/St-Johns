+++
title = "A Story of Food Poverty, Charity and Working Together"
date = "2020-06-19"
image = "archimg/2020/foodbank.jpg"
+++
[About Perth's Foodbank and how our members help it]({{< relref "blog-3" >}}).
