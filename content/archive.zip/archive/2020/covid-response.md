+++
title = "Coronavirus Response"
date = "2020-04-22"
image = "archimg/2020/virtual-meeting.jpg"
+++
Like all other clubs, we have had to suspend our regular meetings during the coronavirus pandemic. We are holding video meetings instead.

Many of our members are donating the money that we would have spent on lunch to our Trust Fund. The first donation from the fund went to {{< extlink label="Perth and Kinross Foodbank" href="https://perthkinross.foodbank.org.uk" >}}.
