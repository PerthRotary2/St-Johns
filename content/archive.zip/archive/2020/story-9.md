+++
title = "Rotary Myth-Busting"
date = "2020-09-23"
+++
[Michael Archibald debunks some myths about Rotary clubs]({{< relref "blog-9" >}}).
