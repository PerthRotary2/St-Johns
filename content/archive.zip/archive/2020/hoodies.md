+++
title = "Hoodies for The Lighthouse"
date = "2020-11-04"
image = "archimg/2020/lighthouse.jpg"
+++
We were delighted to support The Lighthouse for Perth by buying new hoodies for the staff and volunteers.

{{< extlink label="The Lighthouse for Perth" href="https://lighthouseforperth.org" >}} offer support to
anyone aged 12 or over who is struggling with their mental health or emotions.
This includes people who are having thoughts of self-harm or suicide. As well as a listening service, they
provide a safe space for people who are at crisis point.

The service they offer is invaluable, and the staff are amazing! The hoodies are needed so that staff and
volunteers are readily identifiable.