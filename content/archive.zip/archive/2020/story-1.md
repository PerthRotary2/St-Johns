+++
title = "Early Days"
date = "2020-06-15"
image = "archimg/2020/camping-1983.jpg"
+++
[Michael Archibald remembers...]({{< relref "blog-1" >}}).
