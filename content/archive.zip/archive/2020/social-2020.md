+++
title = "Social Evening"
date = "2020-01-28"
image = "archimg/2020/social-2020-1.jpg"
+++
A great meal out at the {{< extlink href="https://www.perth.uhi.ac.uk/business/open-to-the-public/gallery-restaurant/" label="UHI Perth College's training restaurant" >}}. Good fellowship, and the food and service were first class.