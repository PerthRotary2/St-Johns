+++
title = "40 Years in Rotary"
date = "2020-06-28"
image = "archimg/2020/Roger-Ward-2020.jpg"
+++
[Roger Ward writes about what he likes best in Rotary]({{< relref "blog-4" >}}).
