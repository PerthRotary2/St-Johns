+++
title = "My Rotary Story"
date = "2020-06-22"
image = "archimg/2020/robert-1.jpg"
+++
[Robert Macduff-Duncan, our outgoing President, writes about his experience of Rotary.]({{< relref "blog-2" >}}).
