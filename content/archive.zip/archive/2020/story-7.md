+++
title = "Our Members Talk About Rotary"
date = "2020-08-09"
+++
[Members talk on video about their individual experiences of Rotary]({{< relref "blog-7" >}}).