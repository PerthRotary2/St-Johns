+++
title = "Bag Packing at Morrisons"
date = "2020-03-01"
image = "archimg/2020/bag-pack-2020.jpg"
+++
Thanks to Morrisons for hosting our charity bag pack, and to all the customers who donated and helped us raise funds for local charities.