+++
title = "2022"
date = "2022-01-01"
image = "/archimg/2022/handover-2022-1.jpg"
always_show_text = true
description = "Pictures from 2022."
+++