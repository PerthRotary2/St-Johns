+++
title = ""
date = "2022-06-29"
image = "archimg/2022/handover-2022-1.jpg"
+++
The club welcomes Gail Mackay as our new President, with flowers and thanks to Past-President Pam Dickson.
{{< image src="/archimg/2022/handover-2022-2.jpg" >}}
