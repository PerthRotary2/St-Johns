+++
title = "By George, December"
date = "2013-12-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1312.pdf"
+++
