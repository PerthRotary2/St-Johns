+++
title = "Summer barbecue"
date = "2013-08-25"
image = "archimg/Barbecue-13-800.jpg"
+++
Club members enjoying the good weather at our annual barbecue.