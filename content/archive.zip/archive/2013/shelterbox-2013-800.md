+++
title = "Shelterboxes"
date = "2013-09-01"
no_day = true
image = "archimg/shelterbox-2013-800.jpg"
+++
Following our musical evening at Perth Museum we purchased two ShelterBoxes, and they are now on standby for events such as the Syrian refugee crisis or flooding in Sudan.

In such desperate circumstances having a space to call your home is invaluable and each large, green ShelterBox contains a custom-made disaster relief tent for an extended family, designed to withstand extreme temperatures, high winds and heavy rainfall. Also in the Box are blankets, water storage and filtration equipment, a stove, a basic tool kit, a children’s activity pack and other vital items.