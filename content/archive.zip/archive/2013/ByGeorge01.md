+++
title = "By George, January"
date = "2013-01-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1301.pdf"
+++
