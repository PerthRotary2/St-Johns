+++
title = "Rotary Club of Aschaffenburg-Schönbusch visit"
date = "2013-10-18"
image = "archimg/aschaffenburg-2013-800.jpg"
+++
We were delighted to welcome our friends from the Rotary Club of Aschaffenburg-Schönbusch on their weekend visit to Perth. In the picture, the visitors were welcomed at a civic reception by the Provost of Perth, Liz Grant.