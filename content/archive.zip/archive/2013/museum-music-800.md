+++
title = "Summer Concert"
date = "2013-06-14"
image = "archimg/museum-music-800.jpg"
+++
Thank you to everyone who made our June concert at Perth Museum such a success. we raised enough to buy two Shelterboxes.

In the photo are the performers: Henry Neil (musical director), Ian Grieve (compére), Alexander Stewart (baritone), Fiona Brownsmith (soprano), Heather Stewart (mezzo soprano), and Hamish Stewart (bass).