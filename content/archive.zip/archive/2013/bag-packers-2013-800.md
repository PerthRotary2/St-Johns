+++
title = "Bag packing at Marks & Spencers"
date = "2013-12-07"
image = "archimg/bag-packers-2013-800.jpg"
+++
Thank you to all the Marks and Spencers customers who gave so generously when we packed their shopping on Saturday 7th December. We collected just over £1000.

Most of the money donated went to Perth Association for Mental Health, with a smaller amount to the M&S staff nominated charity CHAS.