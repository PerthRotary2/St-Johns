+++
title = "The new team"
date = "2013-07-01"
image = "archimg/new-team-2013.jpg"
+++
The new team for 2013 - President Alexander Stewart and Vice-president Helen MacKinnon.