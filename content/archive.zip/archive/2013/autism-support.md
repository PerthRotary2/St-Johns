+++
title = "Autism Support Donation"
date = "2013-06-25"
image = "archimg/autism-support.jpg"
+++
Vice-president Alexander presented a cheque for £358 to Perth Autism Support project co-ordinator Nicola Acford.

This was half of the proceeds of a concert organised with Perth and Kinross young musicians, held on June 7th at North Muirton Community Campus. The other half went to support the Perth and Kinross central music groups.