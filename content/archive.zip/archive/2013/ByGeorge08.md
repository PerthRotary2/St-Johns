+++
title = "By George, August"
date = "2013-08-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1308.pdf"
+++
