+++
title = "By George, July"
date = "2013-07-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1307.pdf"
+++
