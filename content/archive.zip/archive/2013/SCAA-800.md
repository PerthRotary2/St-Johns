+++
title = "Air Ambulance donation"
date = "2013-01-16"
image = "archimg/SCAA-800.jpg"
+++
President Louis and Vice President Alexander presented a cheque for £500 in support of the new Air Ambulance to be based at Scone Airport. The money was raised from a Saturday bag packing at Marks and Spencer in Perth.