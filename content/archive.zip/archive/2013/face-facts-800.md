+++
title = "Face Facts donation"
date = "2013-10-01"
no_day = true
image = "archimg/face-facts-800.jpg"
+++
President Alexander Stewart presented a cheque for £1500 to surgeon Sean Laverick. The funds will be used to bring a female facial surgeon to Scotland for training in the latest techniques.

Mr Laverick has travelled with the charity Face Facts to disaster areas around the world to perform facial surgery on victims, and to train local surgeons.