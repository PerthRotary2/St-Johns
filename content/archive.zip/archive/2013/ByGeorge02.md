+++
title = "By George, February"
date = "2013-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1302.pdf"
+++
