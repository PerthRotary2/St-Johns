+++
title = "New member"
date = "2013-06-26"
image = "archimg/jennifer-mcomish.jpg"
+++
We welcome new member Jennifer McOmish.