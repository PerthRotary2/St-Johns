+++
title = "New member"
date = "2013-01-09"
image = "archimg/Susan-Hellier-800.jpg"
+++
Susan Hellier joins Rotary. In the photo she is welcomed by Gail MacKay, President Louis and Vice-President Alexander.