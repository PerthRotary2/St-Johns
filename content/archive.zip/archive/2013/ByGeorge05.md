+++
title = "By George, May"
date = "2013-05-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1305.pdf"
+++
