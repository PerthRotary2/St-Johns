+++
title = "By George, October"
date = "2013-10-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1310.pdf"
+++
