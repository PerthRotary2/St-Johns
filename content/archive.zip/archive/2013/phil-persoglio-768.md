+++
title = "New member"
date = "2013-10-18"
image = "archimg/phil-persoglio-768.jpg"
+++
Our latest new member, Phil Persoglio.