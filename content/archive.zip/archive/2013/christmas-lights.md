+++
title = "Christmas Lights fundraising lunch"
date = "2013-11-24"
+++
The ladies of Rotary Club of Perth St John's celebrated a successful afternoon of fashion and fundraising at their Christmas Lights Ladies Charity Lunch on Sunday 24 November at the Royal George Hotel

With a magical Christmas Gifts and Crafts Market setting the scene throughout the hotel, the festive period was officially launched as glamorous ladies from across Scotland came together to raise over £2,700 for local charities.

The highlight of the event was a Catwalk Fashion Show by local boutique Phase Eight who showcased their sparkling winter collection.