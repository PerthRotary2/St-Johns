+++
title = "Coffee morning"
date = "2013-09-28"
image = "archimg/coffee-morning-2013.jpg"
+++
Ready for customers at our fundraising coffee morning in St. Matthews Church Hall.