+++
title = "Foodbank donation"
date = "2013-09-17"
image = "archimg/foodbank-1-800.jpg"
+++
Past President Louis Flood presented a cheque for £540 to Perth & Kinross Foodbank. The foodbank was due to open its doors at the end of September, and work was in progress fitting out and stocking up the St.Catherine's Road premises.