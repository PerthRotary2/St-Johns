+++
title = "Moneyspinner"
date = "2012-06-01"
no_day = true
image = "archimg/MoneySpinner_800.jpg"
+++
Local and international charities are set to benefit from the new 'Moneyspinner' installed at Perth Leisure Pool. Supplied by the Rotary Club of Perth St.Johns, it is hoped that the device proves a fun attraction and will persuade patrons to part with their pocket change and generate funds for worthy causes.

In the photo, club President Heather Stewart and the Leisure Pool's Operations Manager Debbie Scott try their hand with the Moneyspinner.