+++
title = "By George, July/August"
date = "2012-08-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1207.pdf"
+++
