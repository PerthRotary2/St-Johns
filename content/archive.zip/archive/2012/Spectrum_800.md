+++
title = "Donations from Sportsmans Dinner"
date = "2012-03-01"
no_day = true
image = "archimg/Spectrum_800.jpg"
+++
President Heather Stewart and vice-president Louis Flood presented a cheque for £350 to Ann Barrett of Spectrum Club Scotland. The club is for those aged 16yrs and over with Asperger syndrome or higher functioning autism. We also passed on the money raised at the dinner to Marie Curie Cancer Care, ShelterBox, and local charity Headway.