+++
title = "Burns Supper"
date = "2012-01-25"
image = "archimg/Burns_Supper_12_1_800.jpg"
+++
We enjoyed an evening of music and verse our Burns Supper. Club members and friends who entertained the company (from left) Mike Jamieson, David Cuthbert, Club President Heather Stewart, Fraser Bruce, Bruce Thomson, Helen MacKinnon, Alexander Stewart, Stuart Cameron and Piper Ian Stevenson.
{{< image src="/archimg/Burns_Supper_12_2_800.jpg" >}}
{{< image src="/archimg/Burns_Supper_12_3_800.jpg" >}}
