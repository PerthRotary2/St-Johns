+++
title = "By George, November"
date = "2012-11-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1210.pdf"
+++
