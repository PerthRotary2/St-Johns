+++
title = "By George, December"
date = "2012-12-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1211.pdf"
+++
