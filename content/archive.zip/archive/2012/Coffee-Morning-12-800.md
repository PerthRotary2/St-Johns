+++
title = "Coffee Morning"
date = "2012-09-15"
image = "archimg/Coffee-Morning-12-800.jpg"
+++
Our members stand ready to serve at a coffee morning on 15th September in North Church Hall.