+++
title = "By George, August/September"
date = "2012-09-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1208.pdf"
+++
