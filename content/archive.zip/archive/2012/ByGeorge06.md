+++
title = "By George, June / July"
date = "2012-07-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1206.pdf"
+++
