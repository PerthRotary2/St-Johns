+++
title = "Summer Barbecue"
date = "2012-09-09"
image = "archimg/Barbecue-12-800-1.jpg"
summarize = true
+++
Great fun was had by everyone who attended the Club BBQ held in President Louis back garden. Before the BBQ we enjoyed a Treasure Hunt round the North Inch. Afterwards we we tucked in to good food, good refreshments and good company. Thanks to Louis, Fiona and others for organising such an enjoyable afternoon.

<!--more-->
{{< image src="/archimg/Barbecue-12-800-2.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-3.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-4.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-5.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-6.jpg" >}}

The weather was fair, unlike some of the clues, apparently, and a happy conclusion was reached when the competition was won by Maureen and Fraser. (The fact that they took twice as long as anyone else to return to base was the subject of a brief steward’s inquiry, but it was decided their tardiness was not because they’d been spending time cheating on Google, but due to their sheer incompetence at reading the clues).

{{< image src="/archimg/Barbecue-12-800-7.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-8.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-9.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-10.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-11.jpg" >}}
{{< image src="/archimg/Barbecue-12-800-12.jpg" >}}
