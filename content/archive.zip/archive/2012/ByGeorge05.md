+++
title = "By George, May/June"
date = "2012-06-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1205.pdf"
+++
