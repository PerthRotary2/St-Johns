+++
title = "Perth Show"
date = "2012-08-12"
image = "archimg/Perth_Show_12_800.jpg"
summarize = true
+++
We had a great day on the Saturday of Perth Show, with competitions and a duck pond.

Our thanks go to everyone who visited our stand and made a contribution.

Here are a selection of pictures from the day.
{{< image src="/archimg/Perth_Show_2012_1_800.jpg" >}}

<!--more-->
{{< image src="/archimg/Perth_Show_2012_2_800.jpg" >}}
{{< image src="/archimg/Perth_Show_2012_3_800.jpg" >}}