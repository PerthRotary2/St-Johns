+++
title = "Big Picnic"
date = "2012-05-12"
image = "archimg/BigPicnic_300.jpg"
+++
The weather smiled on the Rotarians and friends at Tentsmuir for the picnic on the beach – well at least very close to it. It was a lovely day, a great atmosphere and a lot of very happy people.

The food stall was set with a whole medley of goodies including tomato soup, hot dogs, tray bakes and of course your five a day items apples, tomatoes, cucumbers and bananas – super.

After an ice-breaking game of kill the balloons, the Young Carers and the lads from the Spectrum Club rushed off to the beach to make the best sand structure they could in 30 minutes. The four teams threw themselves into artistic mayhem and it was unclear if it was the younger or older members of the teams who were having the most fun. After being fed and watered more games took place including a tug of war. The young people joined in and seemed to have had a great time and there is no doubt that there will be more Rotary Picnic’s in the future.