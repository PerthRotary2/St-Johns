+++
title = "Annnual Scottish Concert"
date = "2012-02-29"
image = "archimg/Ceilidh_12_800.jpg"
+++
We held our concert for older adults on 29th February. For the first time the event was held at the Gateway in the afternoon. Members of the Gateway Day Club attended as well as older members of Headway (the local brain injury support group which our club is supporting this year.

The entertainment was varied and included performances by young people from Jambouree, with duets from Rotarians Heather and Alexander Stewart. Rotarian Helen MacKinnon brought her fiddle and was accompanied by Anna (from the Gateway) on the accordion.

We also had a fun Scottish Quiz, a sit-down spot dance and a free raffle. A great afternoon ended with a communal sing song of old favourites.