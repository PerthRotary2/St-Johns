+++
title = "Sportsmans Dinner"
date = "2012-02-17"
image = "archimg/SportsmansDinner12_800.jpg"
+++
We had two excellent speakers at our charity dinner in February. Craig Brown CBE, Aberdeen and former Scotland manager, gave us a fascinating and amusing insight into the Scottish Game. He was partnered by journalist Sandy Strang, who kept the whole room laughing throughout his speech.

Thanks to our sponsors, generous gifts for the auction and our guests, we raised over £3000. The money raised at the dinner goes to our nominated charities: Marie Curie Cancer Care, ShelterBox, and local charities the Spectrum Club and Headway. It also helps to fund our activites throughout the year.

Top table guest and speakers, front from left: Ben Gunn, President Rotary Club of Perth; speaker Craig Brown; Club President Heather Stewart; speaker Sandy Strang; Colin Moreland, President Rotary Club of of Perth Kinnoull. Back from left: Rotarians Graham Harding and Rob Burke; MC Gordon Bannerman; auctioneer Ian Smith; Mike Crighton from sponsors Farquhars Ltd.