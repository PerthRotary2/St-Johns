+++
title = "By George, January/February"
date = "2012-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1201.pdf"
+++
