+++
title = "By George, April/May"
date = "2012-05-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1204.pdf"
+++
