+++
title = "Sports Afternoon"
date = "2011-02-06"
image = "archimg/Sports_12_800.jpg"
+++
Some of the club sporty types took part and enjoyed an afternoon of sports fun courtesy of Bells Sports Centre.