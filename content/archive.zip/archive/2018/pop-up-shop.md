+++
title = "Charity Pop-up Shop"
date = "2018-12-01"
image = "archimg/2018/pop-up-shop.jpg"
+++
Treasurer Helen and President Pam welcome the first customers to our charity pop-up shop.

The shop was organised from concept to delivery in just two weeks! We opened on 1st December for 7 days, and raised £2,000  from donated clothes, jewellery, toys, CDs, bric-a-brac and much more.