+++
title = "Donations to Four Local Organisations"
date = "2018-09-12"
image = "archimg/2018/donations-2018.jpg"
+++

We enjoyed the company at lunch of representatives from four local charities and community groups. They received donations totalling £800 from our Club this summer.
{{< extlink href="https://www.pkavs.org.uk" label="PKAVS" >}} Shopmobility,
Perth &amp; Kinross ADHD Support,
{{< extlink href="https://www.iapk.org.uk" label="Independent Advocacy Perth &amp; Kinross" >}},
and {{< extlink href="https://cath-org.co.uk/starter-packs/" label="Perth Starter Packs" >}}.

The donations followed our Club's fundraising efforts during 2017-18. Thank you to all who helped us raise funds and support these important local organisations.