+++
title = "Defibrillator Training"
date = "2018-04-11"
image = "archimg/2018/defibrillator-1.jpg"
+++

We installed an Automated External Defibrillator (AED) in the Royal George Hotel last year. Staff and several of our Rotarians have now been trained to use it.

Although training is desirable, AEDs provide voice instructions and can be used without previous experience. It's essential that the device is used without delay, which is why AEDs are needed in publicly accessible locations like this.

{{< image src="/archimg/2018/defibrillator-2.jpg" >}}