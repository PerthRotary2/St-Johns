+++
title = "Carol Singers"
date = "2018-12-16"
image = "archimg/2018/carols-2018.jpg"
+++
Our singers enjoy a hot drink or mulled wine after singing in Birnam.

Each year we offer to sing at local care homes. This Christmas it was the turn of Luncarty Care Home and Rivendell House in Birnam.
