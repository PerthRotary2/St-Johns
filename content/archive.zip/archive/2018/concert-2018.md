+++
title = "A Little Light Music"
date = "2018-02-09"
image = "archimg/2018/concert-2018.jpg"
+++

The Guitar Ensemble and Percussion Group, together with some of our team (above), and the Wind Ensemble receive applause (below).

In association with {{< extlink href="http://pkcmusic.com" label="Perth and Kinross Music Service" >}}, we presented "A Little Light Music" in St Ninian's Cathedral.

The music was excellent, and the event raised almost £680 for {{< extlink href="https://www.pkavs.org.uk/" label="PKAVS" >}} and Perth and Kinross music groups. Our thanks go to the young musicians, their music tutors, St. Ninian's helpers, and to the audience for their generous donations.