+++
title = "Bag packing"
date = "2018-09-01"
image = "archimg/2018/bag-packing-2018.jpg"
+++

An enjoyable and successful bag packing at Tesco raised £625. (In the photo: Anne Jones, Shona Weir, Ian Dargie, and Pam Dickson.)
