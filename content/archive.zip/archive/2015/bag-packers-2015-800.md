+++
title = "Christmas bag packing"
date = "2015-12-19"
image = "archimg/bag-packers-2015-800.jpg"
+++
We collected just over £1200 in donations from the generous shoppers at Marks and Spencer in Perth.