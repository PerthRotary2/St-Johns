+++
title = "Viewlands Primary School Shelterbox"
date = "2015-03-10"
image = "archimg/viewlands-shelterbox-800.jpg"
+++
Pupils from Viewlands Primary School, previous winners of the Primary Schools Quiz, hand over a cheque for a Shelterbox to President Helen.