+++
title = "RIBI President visits"
date = "2015-05-27"
image = "archimg/RIBI-president-2015-800.jpg"
+++
It was a grand occasion when Peter King, President of Rotary in Great Britain & Ireland, visited our club as part of his tour of the country. The event was attended by Rotarians from all over the area, including the three Perth clubs.

RIBI President Peter swapped commemorative banners with club president Helen MacKinnon. Also in the picture is vice-president Michael Jamieson (left) and District Governor Keith Hopkins (right).