+++
title = "Visit to Aschaffenburg"
date = "2015-11-28"
image = "archimg/aschaffenburg-2015-800.jpg"
+++
Some of our members had a very enjoyable trip to visit our twinned Rotary Club of Aschaffenburg-Schönbusch. Highlights of the trip included a trips to Schönbusch park and Frankfurt Christmas Market, as well as excellent hospitality from our German friends.