+++
title = "New member"
date = "2015-02-11"
image = "archimg/shona-800.jpg"
+++
Shona Weir joins Rotary. In the photo she is welcomed by Michael Jamieson, President Helen MacKinnon and Gail Mackay.