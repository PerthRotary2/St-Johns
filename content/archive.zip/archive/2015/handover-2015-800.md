+++
title = "New Club President"
date = "2015-06-27"
image = "archimg/handover-2015-800.jpg"
attrib = "photo by fraser band photography"
+++
At the Club's Handover Dinner our new President, Michael Jamieson, received the chain from outgoing President Helen MacKinnon. With them is vice-president Gail Mackay and Asst District Governer Alistair Spowage. (photo by fraser band photography)