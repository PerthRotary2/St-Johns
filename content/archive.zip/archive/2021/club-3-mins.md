---
title: "Our Club in 3 Minutes"
date: 2021-06-01
---
See some of the fun community activities we get involved in. From fundraising lunches to planting crocuses to installing a community defibrillator ... there's little we haven't tackled!

{{< video src="images/activities-2020-1.mp4" poster="images/activities-2020.png" >}}
