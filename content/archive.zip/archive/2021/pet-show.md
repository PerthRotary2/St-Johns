+++
title = "Perfect Pets Competition"
date = "2021-11-15"
image = "archimg/2021/rotary-pet-august-sm.jpg"
+++
A gorgeous Vizsla pup from Perth has taken top prize in Perth St Johns Rotary Club's "Perfect Pets" competition, winning a £200 prize for owner Heather Stewart.

Stunning August won the judges' hearts in the Beautiful Baby class before going on to lift the overall title in our fundraising virtual pet show. Other accolades went to submissions from Dundee, Wigan, Stirling, Aberdeenshire and Lasswade.

We're extremely grateful to those who took the time to join in the fun and to donate to our two chosen animal charities: {{< extlink href="https://www.pdsa.org.uk/" label="People's Dispensary for Sick Animals (PDSA)" >}} and {{< extlink href="https://sendacow.org/"label="Send A Cow" >}}.

We also thank the many local businesses who sponsored the event and the judges who were faced with the difficult task of selecting winners.