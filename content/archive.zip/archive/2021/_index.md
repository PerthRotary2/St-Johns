+++
title = "2021"
date = "2021-01-01"
image = "/archimg/2021/rotary-pet-august-sm.jpg"
always_show_text = true
description = "Pictures from 2021."
aliases = [
    "/2021/"
]
+++