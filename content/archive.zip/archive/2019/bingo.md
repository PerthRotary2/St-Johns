+++
title = "Prize Bingo Night Success!"
date = "2019-03-29"
image = "archimg/2019/bingo.png"
+++
Thank you to everyone who came to our Bingo Night. We hope you enjoyed it. We're delighted to announce that you raised over £1,300 for Rotary charities at home and abroad.