+++
title = "Carol Singers"
date = "2019-12-19"
image = "archimg/2019/carols-2019.jpg"
+++
We were well entertained at our Christmas party by our own carol singers. It was their second engagement of the day - they had been singing for the residents of Rivendell Care Home in Birnam in the afternoon.