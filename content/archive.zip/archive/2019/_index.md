+++
title = "2019"
date = "2019-04-26"
image = "/archimg/2019/Aschaffenburg-visit-2019.jpg"
always_show_text = true
description = "Pictures from 2019."
aliases = [
    "/2019/"
]
+++