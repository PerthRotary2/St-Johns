+++
title = "Donations to Local Charities"
date = "2019-10-02"
image = "archimg/2019/donations-2019.jpg"
+++

We have recently made donations to some important charitable causes:
{{< extlink href="https://www.lead.org.uk" label="Lead Scotland" >}}, {{< extlink href="https://www.pkmf.org.uk" label="Perth &amp; Kinross Music Foundation" >}}, and {{< extlink href="https://www.afri-link.org" label="AfrAsia-link" >}}.

Representatives, seen here with President Robert Macduff-Duncan and other Rotarians, joined us at lunch recently to tell us about their work.

We also made donations to {{< extlink href="http://www.thebraintumourcharity.org" label="The Brain Tumour Charity" >}}, and  {{< extlink href="https://www.freedomfromfistula.org" label="Freedom From Fistula" >}}.