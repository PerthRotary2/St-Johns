+++
title = "Visit from Rotary Club of Aschaffenburg-Schönbusch"
date = "2019-04-26"
image = "archimg/2019/Aschaffenburg-visit-2019.jpg"
+++
At the Scottish Parliament with club member Alexander Stewart MSP.

We were delighted to host our old friends, and some new ones, on a weekend visit from Aschaffenburg. Activities included a tour of the Scottish Parliament, a trip to the V&amp;A Museum in Dundee, dinners hosted by our Rotarians, and an international Gavel competition.