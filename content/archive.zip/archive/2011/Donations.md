+++
title = "Donations from the Sportsmans Dinner"
date = "2010-03-31"
no_day = true
image = "archimg/HomeStart_800.jpg"
+++
President Stuart Cameron presented a cheque for £500 to Susan Guild of Home-Start Perth.

Donations were also made to Stepping Stones (a theatre project for the disabled) and YMCA Perth, as well as the international project First Steps Himalaya.

{{< image src="/archimg/CombatStress_800.jpg" >}}
Clive Fairweather of Combat Stress received a cheque for £2000.