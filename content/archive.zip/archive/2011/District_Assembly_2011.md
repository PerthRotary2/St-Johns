+++
title = "District Assembly"
date = "2011-05-01"
image = "archimg/District_Assembly_2011.jpg"
+++
Rob, President Heather, James, Anne, David and Gail at the District Assembly.