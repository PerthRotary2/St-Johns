+++
title = "35th Anniversary Dinner"
date = "2017-03-31"
image = "archimg/Charter_35.jpg"
+++
St Johns Rotarians past and present united to celebrate the club's 35th anniversary in November. Around 40 gathered at the special charter dinner in the Royal George enjoying chat, sharing memories and wining and dining in fellowship. 

Special guest was Scottish biscuit "Royalty" Boyd Tunnock CBE who arrived in his chauffeur driven Rolls Royce to entertain everyone with his pithy and humourous tales from the production line. And there were Tunnocks Caramel Wafers for everyone from the Teacake tycoon and a plea to keep buying more - "to help keep the car on the road". 

A toast to St Johns was given by Louis Flood Snr from the mother club of Perth Rotary and son Louis Flood Jnr - our own Vice President - responded and gave the vote of thanks.