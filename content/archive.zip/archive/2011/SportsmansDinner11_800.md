+++
title = "Sportsmans Dinner"
date = "2011-02-11"
image = "archimg/SportsmansDinner11_800.jpg"
+++
We had two outstanding speakers - Tommy Docherty and Jim Leishman - at our Sportsmans Dinner this year. Both in their different ways are legends in the football sphere, and we had a great evening at the Lovat Hotel in Perth.

Thanks to our sponsors, generous gifts for the auction and our guests, we raised over £5000. The money raised at the dinner goes to our nominated charities, and also helps to fund our activites throughout the year.

Top table guest and organisers : Club President Stuart Cameron is seated centre, flanked by speakers Tommy Docherty and Jim Leishman. On the far left Colin Moreland, President of Perth Kinnoull Rotary Club, and right Charles Evans, President Rotary Club of Perth.