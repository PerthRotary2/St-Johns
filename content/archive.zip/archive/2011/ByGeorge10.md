+++
title = "By George, September/October"
date = "2011-10-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1109.pdf"
+++
