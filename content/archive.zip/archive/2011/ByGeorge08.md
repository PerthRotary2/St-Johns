+++
title = "By George, August/September"
date = "2011-09-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1108.pdf"
+++
