+++
title = "Christmas Party"
date = "2011-12-21"
image = "archimg/Christmas_11_1_800.jpg"
summarize = true
+++
Our last meeting of the year was the Christmas Party, with a delightful musical entertainment from the Jambouree Cabaret Singers.

And we proved that none of us is too old or serious to enjoy Pass the Parcel!

<!--more-->
{{< image src="/archimg/Christmas_11_2_800.jpg" >}}
{{< image src="/archimg/Christmas_11_3_800.jpg" >}}
{{< image src="/archimg/Christmas_11_4_800.jpg" >}}
{{< image src="/archimg/Christmas_11_5_800.jpg" >}}
{{< image src="/archimg/Christmas_11_6_800.jpg" >}}
{{< image src="/archimg/Christmas_11_7_800.jpg" >}}
