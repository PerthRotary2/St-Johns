+++
title = "Summer Barbecue"
date = "2011-08-14"
image = "archimg/Barbecue_11_1_800.jpg"
summarize = true
+++
Once again intrepid members, friends and families headed to The Boathouse at Glenturret for our annual summer BBQ hosted by the Perth and District Branch of the Parachute Regimental Association.

This year the old soldiers had set the club two challenges - one being a fun shoot testing skills with air pistols, balloons, catapults and mint imperials - and the other being an emergency aircraft crash survival scenario.

<!--more-->
Our shooting skills proved "mixed" with fears of a serious lead poisoning issue in the local water supply after hundreds of lead pellets missed the target and soared off into the Loch Turret reservoir! And rumour has it the casualties - who were only slightly injured in the crash - have since died following the tender ministrations of our First Aid heroes! Col Bert announced he wouldn't trust some of us to give a tablet far less perform emergency treatment!

{{< image src="/archimg/Barbecue_11_2_800.jpg" >}}
Needless to say there was the usual friendly rivalry between two teams headed by Stuart and Pam and it went right down to the wire and left to Deadeye Dicks (no offence intended!) Mark Cairns and Graham Harding to do battle in the deciding shootout after points were leveled.

It took "two final shootouts" to see Graham blast the bullseye and emerge victorious with the plaudits going to Pam's delighted team.

Despite mixed weather, everyone enjoyed the day, with outdoor BBQ and indoor hobs allowing everyone to cook up their own favourites and share a meal together. Thanks to all who turned out to join in the fun and for their generous donations which allowed Perth St Johns to