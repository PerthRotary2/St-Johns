+++
title = "By George, November/December"
date = "2011-12-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1111.pdf"
+++
