+++
title = "Curling for the Edinburgh Trophy"
date = "2011-04-05"
image = "archimg/Curling2011.jpg"
+++
Our curlers took the Edinburgh Trophy this year. This is friendly competition between the three Perth Rotary clubs, with curlers of all abilities playing. After the game we all enjoyed high tea at Dewars Rink.