+++
title = "By George, January"
date = "2011-01-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1101.pdf"
+++
