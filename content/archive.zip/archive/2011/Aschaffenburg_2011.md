+++
title = "Visitors from Aschaffenburg"
date = "2011-05-20"
image = "archimg/Aschaffenburg_2011.jpg"
+++
Visitors from our twinned Rotary Club of Aschaffenburg-Schonbusch at the Falkirk Wheel.