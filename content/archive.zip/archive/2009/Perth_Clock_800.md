+++
title = "Rotary Centenary Clock Updated"
date = "2017-03-31"
image = "archimg/Perth_Clock_800.jpg"
+++
New illuminated faces for the Rotary Centenary clock outside Perth Concert Hall. It was presented to the city of Perth in 2005 by the three Perth Rotary clubs to mark the centenary of Rotary International.