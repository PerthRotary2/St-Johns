+++
title = "By George, January"
date = "2009-01-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0901.pdf"
+++
