+++
title = "Senior Citizens Ceilidh"
date = "2009-02-10"
image = "archimg/Ceilidh09_800.jpg"
+++
Our guests enjoying music and songs from the Dunkeld and District Strathspey & Reel Society at the Senior Citizens Ceilidh.