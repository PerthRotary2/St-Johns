+++
title = "By George, November"
date = "2009-11-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0911.pdf"
+++
