+++
title = "Perth Show"
date = "2009-08-01"
image = "archimg/Perth_Show_09_800.jpg"
+++
Over a gloriously sunny two days, more than 300 people enjoyed the fun of trying to find the blue-tipped nail in the haystack. Historically, this challenge has been enormously successful and this year its drawing power was evident yet again.

With over 500 nails in place there were still over 50 winners, at times placing a bit of pressure on reserves! However eventually £225 net was recorded to be donated to various Rotary charities. Additionally, Rotary St. Johns benefited from members being able to discuss its charitable work with interested participants.