+++
title = "Sportsmans Dinner"
date = "2009-02-27"
image = "archimg/SportsmansDinner09_800.jpg"
+++
Our thanks went to all who supported our 11th Charity Dinner at the Lovat Hotel. The money raised went to:

* Shelterbox - an outstanding Rotary charity which delivers urgent emergency support to devastated communities worldwide.

* Cash for Kids (formerly Caring for Kids) - a Tayside based charity which offers imaginative and wide ranging help to disadvantaged young people in our community.

* Our own Charity account which assists a wide range of charities in our community and elsewhere.
