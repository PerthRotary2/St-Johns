+++
title = "By George, March"
date = "2009-03-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0903.pdf"
+++
