+++
title = "By George, June"
date = "2009-06-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0906.pdf"
+++
