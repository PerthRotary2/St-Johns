+++
title = "Hoist for PRI Stroke Unit"
date = "2009-08-15"
image = "archimg/PRI_Hoist_800.jpg"
+++
We bought a much-needed hoist for PRI Stroke Rehabilitation Unit. After it was installed, club president Ian went to see it demonstrated.

The track allows patients to be supported safely and comfortably while they exercise. Ian reported that it is a very impressive piece of equipment which clearly is a huge asset to the staff in the unit, and to all the patients over the coming years who will benefit from using it on their journey of recovery following a stroke.