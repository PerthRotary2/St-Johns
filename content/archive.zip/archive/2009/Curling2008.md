+++
title = "Curling Success"
date = "2009-02-01"
no_day = true
image = "archimg/Curling2008.jpg"
+++
At the Curling Competition for the Edinburgh Trophy against the other two Perth Clubs on Thu 6th Nov the Perth St John’s curlers were in devastating form winning all four games. John Fyfe received the Trophy on behalf of the winning team. Interviewed later by the By George curling correspondent, John stated that he put this win down to hard work and concentration by everyone in the team. He particularly paid tribute to Mark Cairns and Paul Kyle who are new to curling and are already displaying considerable skill and enthusiasm. The Curlers will look forward to defending the Trophy next year.

Stuart Cameron, Ian Mutch, David Grant and Rob Burke played in the first rounds of the Rams Head Competition on Sun 2nd Nov. While they won the first game against the Rotary Club of Glasgow they lost the second game against the Rotary Club of Perth. The top four teams go through to the next stage but as we finished in 5th place we just missed out.

On a brighter note Perth St Johns have played the first two rounds of the Perthshire Rotary League winning both games and are at present top of the league.

{{< image src="/archimg/Jewel_09_800.jpg" >}}
The club continued its run of success in the new year by winning the Rotary Jewel competition.