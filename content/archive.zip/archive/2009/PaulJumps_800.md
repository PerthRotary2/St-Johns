+++
title = "JVP Paul Jumps for Polio Plus"
date = "2009-05-14"
image = "archimg/PaulJumps_800.jpg"
+++
I completed my 'jump' on Thursday 14th May and found the whole experience really exhilarating. Quite a rush it has to be said - hurtling to the earth at 120 mph. Check out my cheeks in the photo - that's what you get for going at that speed not safely inside a vehicle!!

Thanks to everyone who raised sponsorship for Polio Plus.