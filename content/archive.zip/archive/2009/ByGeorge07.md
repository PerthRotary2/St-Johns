+++
title = "By George, July"
date = "2009-07-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0907.pdf"
+++
