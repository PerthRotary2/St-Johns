+++
title = "By George, February"
date = "2009-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0902.pdf"
+++
