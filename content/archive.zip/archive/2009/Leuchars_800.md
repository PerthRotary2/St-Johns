+++
title = "Young Carers Day Out to RAF Leuchars"
date = "2009-07-08"
image = "archimg/Leuchars_800.jpg"
+++
Maureen and Rob accompanied a dozen youngsters from the Princess Royal Trust for Young Carers on a day out to RAF Leuchars.

The highlight of the day was an inspection of a front line Tornado F3 with pilots from No. 111 Squadron.