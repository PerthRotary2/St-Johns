+++
title = "By George, April"
date = "2009-04-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0904w.pdf"
+++
