+++
title = "By George, October"
date = "2009-10-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0910.pdf"
+++
