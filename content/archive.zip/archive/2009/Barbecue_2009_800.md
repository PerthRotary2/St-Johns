+++
title = "Summer Barbecue"
date = "2009-08-30"
image = "archimg/Barbecue_2009_800.jpg"
+++
2009 will go down as the barbecue summer that wasn’t. But did we let that get us down? No, of course not and the annual club BBQ went ahead as planned, albeit inside with the heating on.

The first challenge was getting the barbecue lit, as ever Stuart Cameron came to the rescue, surprisingly with a screwdriver rather than a match. Our three chefs were magnificent.

Next delight was the many salads and puddings, not least Jeanette’s clouty dumpling & pavlova. A drink, a burger and a salad along with some excellent company and it was all over for another year.