+++
title = "Aschaffenburg-Schonbusch Partnership"
date = "2006-06-23"
image = "archimg/Aschaffenburg_06_02_800.jpg"
summarize = true
+++
Club Presidents Gebhard and George sign a partnership between our clubs.

<!--more-->
{{< image src="/archimg/Aschaffenburg_06_03_800.jpg" >}}
{{< image src="/archimg/Aschaffenburg_06_01_800.jpg" >}}
