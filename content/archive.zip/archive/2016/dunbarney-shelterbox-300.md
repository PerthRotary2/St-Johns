+++
title = "Dunbarney Primary School Shelterbox"
date = "2016-01-25"
image = "archimg/dunbarney-shelterbox-300.jpg"
+++
We were delighted to help P5 pupils at Dunbarney Primary School with their ShelterBox project. The class gave a great presentation to the school and to their parents, about natural disasters and how ShelterBoxes can help. They will be following this up with fundraising activities.