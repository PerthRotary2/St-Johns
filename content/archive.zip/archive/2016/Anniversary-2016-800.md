+++
title = "Anniversary dinner"
date = "2016-10-26"
image = "archimg/Anniversary-2016-800.jpg"
+++
We were delighted to celebrate 40 years of serving the community this year!

Our Club's 40th Anniversary Dinner took place at the Royal George Hotel. The event brought together 36 Rotarians, partners and guests together for an evening of entertainment and memories from over the years.

President Michael and Vice President Gail were joined by founding President Donald McDonald and one of our founding members Graham Harding to cut the anniversary cake.