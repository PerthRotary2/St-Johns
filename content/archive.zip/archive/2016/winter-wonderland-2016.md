+++
title = "Winter Wonderland - Ladies Afternoon Tea"
date = "2016-12-14"
image = "archimg/winter-wonderland-2016.jpg"
+++
What an amazing event we had! Fun, fashion, fundraising, fizz, fitness and many, many laughs. We projected the final total raised to be over £3,400.