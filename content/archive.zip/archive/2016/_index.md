+++
title = "2016"
date = "2016-12-31"
image = "/archimg/Alzheimer-800.jpg"
always_show_text = true
description = "Pictures from 2016."
aliases = [
    "/2016/"
]
+++