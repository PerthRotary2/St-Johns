+++
title = "Sportsmans Dinner"
date = "2010-02-19"
image = "archimg/Heroes_Cheque_800.jpg"
+++
Legendary Scottish comedian and broadcaster Andy Cameron was the headline speaker at our Sportsman's Dinner on Friday February 19. Andy was supported by Perth Racecource's general manager Sam Morshead and master of ceremonies was Gordon Bannerman.

We thank our sponsors, guests who bid at the auction, and everyone who bought tickets. With your help we raised over £5,500.

The money raised went to Help for Heroes and three local organisations - DISIP (Disability Information Service in Perthshire, Perthshire Women's Aid and CheckIn Group. It also helped fund the work of our club over the next year.