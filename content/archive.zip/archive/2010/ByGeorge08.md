+++
title = "By George, August"
date = "2010-08-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1008.pdf"
+++
