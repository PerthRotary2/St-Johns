+++
title = "Summer Barbecue"
date = "2010-08-08"
image = "archimg/Barbecue_10_1_800.jpg"
summarize = true
+++
Survival was the challenge at this year's barbecue! Fortunately we had the help of a team from the P & K Parachute Regimental Association to show us what to do.

{{< image src="/archimg/Barbecue_10_2_800.jpg" >}}

<!--more-->
{{< image src="/archimg/Barbecue_10_5_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_6_800.jpg" >}}
After lessons in basic survival, fire lighting, and shelter building, we practiced preparing food caught in the wild.

{{< image src="/archimg/Barbecue_10_7_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_8_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_9_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_10_800.jpg" >}}
We might have starved, had we not brought food and drink for a barbecue at the Boathouse by Loch Turret Dam.

{{< image src="/archimg/Barbecue_10_3_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_12_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_13_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_11_800.jpg" >}}
{{< image src="/archimg/Barbecue_10_4_800.jpg" >}}
