+++
title = "Visit to Aschaffenburg"
date = "2010-05-16"
image = "archimg/Aschaffenburg_10_1_800.jpg"
+++
