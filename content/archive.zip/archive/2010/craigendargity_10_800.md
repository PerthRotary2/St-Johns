+++
title = "Craigendargity Trophy"
date = "2010-08-19"
image = "archimg/craigendargity_10_800.jpg"
+++
The Craigendargity Trophy for visually impaired bowlers was held in Stonehaven. The picture shows Arthur Duncan (District Sports Officer) and Douglas Knox (President, RC of Stonehaven) presenting the Perth St Johns team with the trophy.
