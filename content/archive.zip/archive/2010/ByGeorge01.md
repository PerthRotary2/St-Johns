+++
title = "By George, January"
date = "2010-01-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1001.pdf"
+++
