+++
title = "Perth Show"
date = "2010-08-07"
image = "archimg/Perth_Show_10_800.jpg"
+++
We had a ShelterBox on show. The "Find a Nail" competition raised over £300, and with the recent Pakistan flooding in mind, we used the money to buy another ShelteBox - our 12th to date.