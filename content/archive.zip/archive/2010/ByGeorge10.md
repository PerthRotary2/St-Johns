+++
title = "By George, October"
date = "2010-10-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1010.pdf"
+++
