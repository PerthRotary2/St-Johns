+++
title = "By George, July"
date = "2010-07-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1007.pdf"
+++
