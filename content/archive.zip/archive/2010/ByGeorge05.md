+++
title = "By George, May"
date = "2010-05-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1005w.pdf"
+++
