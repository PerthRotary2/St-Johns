+++
title = "Christmas Parcels Delivery"
date = "2010-12-20"
no_day = true
+++
Once again we delivered Christmas Goodwill parcels to 230 families and pensioners in Perth. Due to the exceptional wintry weather it was not an easy task, but our members coped with the mountains of snow and slippery pavements that were everywhere in Perth. The parcels are provided by PKAVS.