+++
title = "By George, February"
date = "2010-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1002w.pdf"
+++
