+++
title = "Black Watch Honorary Membership"
date = "2010-04-01"
no_day = true
image = "archimg/Black_Watch_800.jpg"
+++
We were proud to welcome The Black Watch, 3rd Battalion Royal Regiment of Scotland as honorary members of our club.

Honorary membership is the highest distinction a Rotary club can confer, and is given to recognise exceptional service and contribution to society.

Honorary membership is the highest distinction a Rotary club can confer, and is given to recognise exceptional service and contribution to society. Membership is normally given to individuals, so we have extended membership via a representative of The Black Watch, Colonel Brigadier Mike Riddell-Webster.