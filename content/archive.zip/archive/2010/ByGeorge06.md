+++
title = "By George, June"
date = "2010-06-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1006w.pdf"
+++
