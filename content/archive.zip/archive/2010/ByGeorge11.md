+++
title = "By George, November"
date = "2010-11-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1011.pdf"
+++
