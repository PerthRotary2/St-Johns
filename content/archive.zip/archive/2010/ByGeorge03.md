+++
title = "By George, March"
date = "2010-03-01"
type = "bgpdf"
file = "bygeorge/ByGeorge1003w.pdf"
+++
