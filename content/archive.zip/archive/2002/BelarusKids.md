+++
title = "Visit by children from Belarus"
date = "2002-04-01"
no_day = true
image = "archimg/BelarusKids.jpg"
+++
