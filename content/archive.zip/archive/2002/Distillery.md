+++
title = "Fellowship Weekend, Pitlochry"
date = "2003-03-31"
image = "archimg/Distillery.jpg"
+++
Taken at Edradour Distillery. The date is a guess.