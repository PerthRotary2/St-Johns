+++
title = "Young Carers Day"
date = "2005-11-20"
image = "archimg/YoungCarers_05_01_800.jpg"
summarize = true
+++
The Princess Royal Trust for Young Carers is supported by all three Rotary clubs in Perth. This event was a day of activities for young carers at Bells Sports Centre. Rotarians manned many of the stalls.

<!--more-->
{{< image src="/archimg/YoungCarers_05_02_800.jpg" >}}
Lunch was provided.

{{< image src="/archimg/YoungCarers_05_03_800.jpg" >}}
The army and Perth & Kinross Council contributed too.

