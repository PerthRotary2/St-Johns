+++
title = "Rotary Club of Aschaffenburg-Schonbusch visit to Perth"
date = "2005-06-15"
no_day = true
image = "archimg/Aschaffenburg_05_01_800.jpg"
+++
Whisky tasting ...

{{< image src="/archimg/Aschaffenburg_05_02_800.jpg" >}}
... followed by a Ceilidh.

{{< image src="/archimg/Aschaffenburg_05_03_800.jpg" >}}
Visiting Scone Palace.

{{< image src="/archimg/Aschaffenburg_05_04_800.jpg" >}}
After lunch at Marrayshall.

