+++
title = "By George, September"
date = "2005-09-01"
type = "bglink"
href = "bygeorge/ByGeorge0509.htm"
+++
<div>&nbsp;</div>
{{< bglink label="P3" href="bygeorge/ByGeorge0509_files/page0002.htm" >}}
{{< bglink label="P4" href="bygeorge/ByGeorge0509_files/page0003.htm" >}}
