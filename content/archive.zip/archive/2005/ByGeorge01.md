+++
title = "By George, January"
date = "2005-01-01"
type = "bglink"
href = "bygeorge/ByGeorge0501.htm"
+++