+++
title = "Perth Show"
date = "2005-08-01"
image = "archimg/PerthShow20051.jpg"
+++
{{< image src="/archimg/PerthShow20052.jpg" >}}

