+++
title = "By George, July"
date = "2005-07-01"
type = "bglink"
href = "bygeorge/ByGeorge0507.htm"
+++
