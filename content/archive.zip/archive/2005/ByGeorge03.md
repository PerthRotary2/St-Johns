+++
title = "By George, March"
date = "2005-03-01"
type = "bglink"
href = "bygeorge/ByGeorge0503.htm"
+++
Beware: one of the articles was an April fool!
