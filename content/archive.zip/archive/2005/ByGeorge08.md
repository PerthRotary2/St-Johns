+++
title = "By George, August"
date = "2005-08-01"
type = "bglink"
href = "bygeorge/ByGeorge0508.htm"
+++
