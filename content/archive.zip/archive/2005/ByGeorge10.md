+++
title = "By George, October"
date = "2005-10-01"
type = "bglink"
href = "bygeorge/ByGeorge0510.htm"
+++
<div>&nbsp;</div>
{{< bglink label="P2" href="bygeorge/ByGeorge0510_files/page0001.htm" >}}
{{< bglink label="P3" href="bygeorge/ByGeorge0510_files/page0002.htm" >}}
{{< bglink label="P4" href="bygeorge/ByGeorge0510_files/page0003.htm" >}}
{{< bglink label="P5" href="bygeorge/ByGeorge0510_files/page0004.htm" >}}
{{< bglink label="P6" href="bygeorge/ByGeorge0510_files/page0005.htm" >}}