+++
title = "Summer Barbecue at Gask Hall"
date = "2005-08-21"
image = "archimg/Barbecue20051.jpg"
summarize = true
+++
{{< image src="/archimg/Barbecue20052.jpg" >}}

<!--more-->
{{< image src="/archimg/Barbecue20053.jpg" >}}
{{< image src="/archimg/Barbecue20054.jpg" >}}
{{< image src="/archimg/Barbecue20055.jpg" >}}
{{< image src="/archimg/Barbecue20056.jpg" >}}
{{< image src="/archimg/Barbecue20057.jpg" >}}
{{< image src="/archimg/Barbecue20058.jpg" >}}
{{< image src="/archimg/Barbecue20059.jpg" >}}
{{< image src="/archimg/Barbecue200510.jpg" >}}
{{< image src="/archimg/Barbecue200511.jpg" >}}
