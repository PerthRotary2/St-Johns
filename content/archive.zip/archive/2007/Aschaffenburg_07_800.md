+++
title = "Visitors from RC of Aschaffenburg Schonbusch on Kinnoull Hill"
date = "2007-05-06"
image = "archimg/Aschaffenburg_07_800.jpg"
+++
