+++
title = "By George, September"
date = "2007-09-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0709.pdf"
+++
