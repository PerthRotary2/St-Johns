+++
title = "On Ben Vorlich"
date = "2007-09-23"
image = "archimg/BenVorlich.jpg"
+++
Taking part in a Water Aid challenge, to put a team on the summit of every Munro between 12 and 2pm.