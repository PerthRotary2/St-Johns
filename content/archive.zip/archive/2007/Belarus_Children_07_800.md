+++
title = "Children from Chernobyl Childrens Lifeline visit the club"
date = "2006-06-18"
image = "archimg/Belarus_Children_07_800.JPG"
+++
