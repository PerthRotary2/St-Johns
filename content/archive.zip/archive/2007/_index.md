+++
title = "2007"
date = "2007-12-31"
image = "/archimg/Belarus_Children_07_800.JPG"
always_show_text = true
description = "Pictures and By George from 2007."
aliases = [
    "/2007/"
]
+++
After a gap in production, By George magazine was produced using Serif PagePlus and saved as PDF for distribution by email and via the web site.