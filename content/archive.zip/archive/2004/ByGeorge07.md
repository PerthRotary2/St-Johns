+++
title = "By George, July"
date = "2004-07-01"
type = "bglink"
href = "bygeorge/ByGeorge0407.htm"
+++
