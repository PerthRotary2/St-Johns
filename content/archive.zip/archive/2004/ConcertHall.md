+++
title = "Visit to Perth Concert Hall, under contruction"
date = "2004-09-20"
image = "archimg/ConcertHall.jpg"
+++
