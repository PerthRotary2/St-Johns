+++
title = "Paul Harris Fellows"
date = "2004-12-29"
image = "archimg/PaulHarrisFellows1.jpg"
+++
Paul Harris Fellowships have been awarded to four long-serving members of our club, to mark the Rotary centenary celebrations. Between them, they have 116 years of service. (Left to right: Alex Hay, Albert Donaldson, Pres. Maureen Young, Ian Agnew, Gordon McFatridge)