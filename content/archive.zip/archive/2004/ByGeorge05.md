+++
title = "By George, May"
date = "2004-05-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0405.pdf"
+++
