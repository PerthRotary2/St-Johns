+++
title = "2004"
date = "2004-12-31"
image = "/archimg/PaulHarrisFellows1.jpg"
always_show_text = true
description = "Pictures and By George from 2004"
aliases = [
    "/2004/"
]
+++
The first few copies of By George were posted as PDF files. Later the ability of MS Publisher to generate web pages was used. The pages were edited to provide forward and back navigation. (Browser standards have changed over the years, and these pages don't display as well as they once did.)