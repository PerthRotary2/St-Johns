+++
title = "By George, August"
date = "2004-08-01"
type = "bglink"
href = "bygeorge/ByGeorge0408.htm"
+++