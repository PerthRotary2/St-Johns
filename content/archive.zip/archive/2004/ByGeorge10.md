+++
title = "By George, October"
date = "2004-10-01"
type = "bglink"
href = "bygeorge/ByGeorge0410.htm"
+++