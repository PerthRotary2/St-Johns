+++
title = "A publicity photo for the Sportsmans Dinner"
date = "2004-01-15"
no_day = true
image = "archimg/Phoenix.jpg"
+++
President David Ramsay with Phoenix.
