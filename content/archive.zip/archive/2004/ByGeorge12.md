+++
title = "By George, December"
date = "2004-12-01"
type = "bglink"
href = "bygeorge/ByGeorge0412.htm"
+++
