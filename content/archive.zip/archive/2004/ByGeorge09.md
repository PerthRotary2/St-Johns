+++
title = "By George, September"
date = "2004-09-01"
type = "bglink"
href = "bygeorge/ByGeorge0409.htm"
+++