+++
title = "By George, April"
date = "2004-04-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0404.pdf"
+++
