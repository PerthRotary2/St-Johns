+++
title = "By George, February"
date = "2004-02-01"
type = "bgpdf"
file = "bygeorge/ByGeorge0402.pdf"
+++
