+++
title = "Perth Show"
date = "2004-08-06"
image = "archimg/PerthShow20041e.jpg"
+++
{{< image src="/archimg/PerthShow20042.jpg" >}}