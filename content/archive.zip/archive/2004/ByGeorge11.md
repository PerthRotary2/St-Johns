+++
title = "By George, November"
date = "2004-11-01"
type = "bglink"
href = "bygeorge/ByGeorge0411.htm"
+++