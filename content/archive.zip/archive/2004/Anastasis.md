+++
title = "Visiting the Mercy Ship Anastasis, in Dundee"
date = "2004-09-16"
image = "archimg/Anastasis.jpg"
+++
