+++
title = "Visit by RC of Aschaffenburg Schonusch"
date = "2004-11-06"
image = "archimg/ASVisit1.jpg"
summarize = true
+++
We welcomed a party from our twin Rotary Club for the weekend of 5-7 November.
{{< image src="/archimg/ASVisit2.jpg" >}}

<!--more-->
{{< image src="/archimg/ASVisit3.jpg" >}}
