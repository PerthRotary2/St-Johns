+++
title = "Rotary Awareness Stand"
date = "2003-02-24"
image = "archimg/StJohnsStand.jpg"
+++
In the St Johns Centre. 

