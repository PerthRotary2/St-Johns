+++
title = "Barbecue"
date = "2003-08-24"
image = "archimg/Barbecue1.jpg"
+++
{{< image src="/archimg/Barbecue2.jpg" >}}