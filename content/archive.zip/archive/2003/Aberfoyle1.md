+++
title = "Fellowship weekend, Aberfoyle"
date = "2003-03-15"
image = "/archimg/Aberfoyle1.jpg"
+++
{{< image src="/archimg/Aberfoyle2.jpg" >}}

