+++
title = "Christmas carol singing"
date = "2003-12-19"
image = "archimg/CarolSingers.jpg"
+++
At Ochil Nursing Home.
