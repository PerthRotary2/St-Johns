+++
title = "Hot Mikado programme sponsored"
date = "2003-01-01"
no_day = true
image = "archimg/HotMikado.jpg"
+++
President Sandy Scrimgeour presents a cheque to sponsor the programmes for Perth Amateur Operatic Society's production of Hot Mikado.