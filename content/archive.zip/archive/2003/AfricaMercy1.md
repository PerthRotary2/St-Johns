+++
title = "Visiting the Africa Mercy"
date = "2003-03-29"
no_day = true
image = "/archimg/AfricaMercy1.jpg"
+++
At the end of March 2003, Sandy Scrimgeour, David Ramsay, Neil Townend and Maureen Young went to visit the Africa Mercy in Newcastle. This ship was being refitted as a hospital ship for the Mercy Ships charity with support from the Balcraig Foundation.
{{< image src="/archimg/AfricaMercy2.jpg" >}}


