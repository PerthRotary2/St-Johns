+++
title = "Roll-a-dice stall at Perth market"
date = "2003-09-30"
no_day = true
image = "archimg/Market1.jpg"
+++
{{< image src="/archimg/Market2.jpg" >}}