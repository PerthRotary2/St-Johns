+++
title = "Old folks ceilidh"
date = "2003-03-10"
image = "/archimg/Ceilidh.jpg"
+++
{{< image src="/archimg/Ceilidh1.jpg" >}}
