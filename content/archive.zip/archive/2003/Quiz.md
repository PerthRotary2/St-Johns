+++
title = "Primary Schools Quiz"
date = "2003-01-23"
image = "archimg/Quiz.jpg"
+++
In the Salutation Hotel. 

