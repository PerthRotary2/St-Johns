+++
title = "Selling mince pies at Perth Christmas market"
date = "2003-12-21"
image = "archimg/MincePies.jpg"
+++
