+++
title = "Primary School Quiz - Zone Final"
date = "2003-04-25"
image = "archimg/QuizZone.jpg"
+++
We hosted the Zone 5 final of the primary schools quiz. 5 schools took part: Auchterarder, Cleish, Kenmore, St Johns Alloa, and Viewlands. The evening was enlivened by radio presenter Fraser Thomson and well attended by parents and supporters. 

Auchterarder were the winners and were joined by Viewlands in our district final. David Rankin (our district community and vocational convenor) presented the trophies to Auchterarder, and all the participants and reserves received a certificate.
