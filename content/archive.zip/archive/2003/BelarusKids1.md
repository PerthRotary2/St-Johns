+++
title = "Visit by children from Belarus"
date = "2003-04-15"
image = "/archimg/BelarusKids1.jpg"
no_day = true
+++
{{< image src="/archimg/BelarusKids2.jpg" >}}

