+++
title = "District Assembly"
date = "2003-05-11"
image = "archimg/DistrictAssembly.jpg"
+++
The incoming team at the Assembly in Aberdeen.
