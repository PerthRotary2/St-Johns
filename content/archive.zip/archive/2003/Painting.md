+++
title = "Painting at a care home"
date = "2003-10-26"
image = "archimg/Painting.jpg"
+++
